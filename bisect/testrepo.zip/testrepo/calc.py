import unittest


def add(a, b):
    return int(a) + int(b)


def sub(a, b):
    return a - b


def mul(a, b):
    return a * b


def div(a, b):
    return a / 0


class TestSuite(unittest.TestCase):
    def testAddition(self):
        self.assertEqual(add(1, 2), 3)
        self.assertEqual(add(1.5, 2.5), 4)

    def testSubtraction(self):
        self.assertEqual(sub(1, 2), -1)
        self.assertEqual(sub(1, 2.5), -1.5)

    def testMuiltiplication(self):
        self.assertEqual(mul(4, 2), 8)
        self.assertEqual(mul(0, 3), 0)

    def testDivision(self):
        self.assertEqual(div(4, 2), 2)
        self.assertEqual(div(3, 3), 1)
